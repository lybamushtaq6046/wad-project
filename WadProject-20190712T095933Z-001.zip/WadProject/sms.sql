-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 16, 2018 at 08:00 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sms`
--

-- --------------------------------------------------------

--
-- Table structure for table `classroom`
--

CREATE TABLE `classroom` (
  `ClassRoomId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `CourseId` int(11) NOT NULL,
  `CourseName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `exam`
--

CREATE TABLE `exam` (
  `ExamId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `grade`
--

CREATE TABLE `grade` (
  `GradeId` int(11) NOT NULL,
  `GradeName` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `StudentId` int(11) NOT NULL,
  `StudentName` varchar(25) NOT NULL,
  `FatherName` varchar(25) NOT NULL,
  `Gender` varchar(12) NOT NULL,
  `MotherName` varchar(25) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Dob` date NOT NULL,
  `Address` varchar(225) NOT NULL,
  `PhoneNo` varchar(11) NOT NULL,
  `Class` int(11) NOT NULL,
  `Section` varchar(1) NOT NULL,
  `Password` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`StudentId`, `StudentName`, `FatherName`, `Gender`, `MotherName`, `Email`, `Dob`, `Address`, `PhoneNo`, `Class`, `Section`, `Password`) VALUES
(1, 'Ahmad Ali', 'Muhammad Ali ', 'Male', 'Zainab Ali', 'Ahmad_ali@student.com', '2014-01-01', '234,Block A,Johar Town,Lahore', '03334142434', 1, 'A', 'abcd001'),
(2, 'Amna Khan', 'Abdullah Khan', 'Female', 'Ghazala Khan', 'Amna_khan@student.com', '2015-12-01', '23,Block A,Model Town,lahore', '03354422011', 1, 'A', 'abcd002');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `Teacherid` int(11) NOT NULL,
  `Teachername` varchar(25) NOT NULL,
  `FatherName` varchar(25) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(25) NOT NULL,
  `Dob` date NOT NULL,
  `Address` varchar(225) NOT NULL,
  `PhoneNo` varchar(12) NOT NULL,
  `Gender` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`Teacherid`, `Teachername`, `FatherName`, `Email`, `Password`, `Dob`, `Address`, `PhoneNo`, `Gender`) VALUES
(1, 'Adil Ahmad', 'Muhammad Ahmad', 'Adil_ali@teacher.com', 'xyz001', '1992-01-01', '45, Block A, Johar town, Lahore.', '03332525250', 'Male'),
(2, 'Umar Malik', 'Malik Faraz', 'Umar_malik@teacher.com', 'xyz002', '1992-02-03', '34, Block G3, Raiwind Road, Lahore.', '03102233445', 'Male');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `classroom`
--
ALTER TABLE `classroom`
  ADD PRIMARY KEY (`ClassRoomId`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`CourseId`);

--
-- Indexes for table `exam`
--
ALTER TABLE `exam`
  ADD PRIMARY KEY (`ExamId`);

--
-- Indexes for table `grade`
--
ALTER TABLE `grade`
  ADD PRIMARY KEY (`GradeId`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`StudentId`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`Teacherid`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
