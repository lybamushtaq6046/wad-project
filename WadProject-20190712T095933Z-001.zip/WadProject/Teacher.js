


$(document).ready(function(){
		$("#TNewNotice").hide();
		$("#TAttendence").hide();
		$("#AttendenceSheet").hide();
		$("#TEmailAccInfo").hide();
		$("#TTimetable").hide();
		$("#TChangePassword").hide();
	
	$("#home").click(function(){
		$("#THome").show();
		$("#TNewNotice").hide();
		$("#TAttendence").hide();
		$("#AttendenceSheet").hide();
		$("#TEmailAccInfo").hide();
		$("#TTimetable").hide();
		$("#TChangePassword").hide();	
		});
		
	$("#newNotice").click(function(){
		$("#THome").hide();
		$("#TNewNotice").show();
		$("#TAttendence").hide();
		$("#AttendenceSheet").hide();
		$("#TEmailAccInfo").hide();
		$("#TTimetable").hide();
		$("#TChangePassword").hide();	
		});
		
		$("#emailAccInfo").click(function(){
		$("#THome").hide();
		$("#TNewNotice").hide();
		$("#TAttendence").hide();
		$("#AttendenceSheet").hide();
		$("#TEmailAccInfo").show();
		$("#TTimetable").hide();
		$("#TChangePassword").hide();	
		});
		
		$("#timetable").click(function(){
		$("#THome").hide();
		$("#TNewNotice").hide();
		$("#TAttendence").hide();
		$("#AttendenceSheet").hide();
		$("#TEmailAccInfo").hide();
		$("#TTimetable").show();
		$("#TChangePassword").hide();	
		});
		
		$("#attendence").click(function(){
		$("#THome").hide();
		$("#TNewNotice").hide();
		$("#TAttendence").show();
		$("#AttendenceSheet").hide();
		$("#TEmailAccInfo").hide();
		$("#TTimetable").hide();
		$("#TChangePassword").hide();	
		});
		
		$("#AttendenceSheet").click(function(){
		$("#THome").hide();
		$("#TNewNotice").hide();
		$("#TAttendence").hide();
		$("#AttendenceSheet").show();
		$("#TEmailAccInfo").hide();
		$("#TTimetable").hide();
		$("#TChangePassword").hide();	
		});
		
		$("#changePassword").click(function(){
		$("#THome").hide();
		$("#TNewNotice").hide();
		$("#TAttendence").hide();
		$("#AttendenceSheet").hide();
		$("#TEmailAccInfo").hide();
		$("#TTimetable").hide();
		$("#TChangePassword").show();	
		});

	
});
