<?php
session_start();

include("DataAccessHelper.php"); 
		
$Email;
$Password;
//student
if(isset($_POST['SEmail'])  && isset($_POST['SPassword']))
{
	$Email=$_POST['SEmail'];
	$Password=$_POST['SPassword'];
	
	$sql = 'select * from student where Email="' . $Email . '" and Password="' . $Password . '";';

	$result = $conn->query($sql);
	
	if ($result) 
	{
    // output data of each row
    if($rs = $result->fetch_assoc()) 
	{
		if($rs["Email"]==$Email && $rs["Password"]==$Password)
		{
		$_SESSION['logged_in_user']=array('name'=>$rs->name,'email'=>$Email);
		echo "<script>window.location.replace('StudentHome.html');</script>";
		}
    }
	else 
	{
		echo "<script>window.alert('Invalid Email or Password!');</script>";
	    echo "<script>window.location.replace('/WadProject/login.html');</script>";
	}
	} 
	
}


//Teacher
else if(isset($_POST['TEmail']) && isset($_POST['TPassword']))
{
	$Email=$_POST['TEmail'];
	$Password=$_POST['TPassword'];
	
		$sql = 'select * from teacher where Email="' . $Email . '" and Password="' . $Password . '";';

	$result = $conn->query($sql);
	
	if ($result) 
	{
    if($rs = $result->fetch_assoc()) 
	{
		if($rs["Email"]==$Email && $rs["Password"]==$Password)
	{
		$_SESSION['logged_in_user']=array('name'=>$rs->name,'email'=>$Email);
		echo "<script>window.location.replace('TeacherHome.html');</script>";
	}
    }
	else 
	{
		echo "<script>window.alert('Invalid Email or Password!');</script>";
	    echo "<script>window.location.replace('/WadProject/login.html');</script>";
    
	}
	} 
	
} 
//admin
else if(isset($_POST['AEmail']) && isset($_POST['APassword']))
{
	$Email=$_POST['AEmail'];
	$Password=$_POST['APassword'];
	
		$sql = 'select * from student where Email="' . $Email . '" and Password="' . $Password . '";';

	$result = $conn->query($sql);
	
	if ($result) 
	{
    // output data of each row
    if($rs = $result->fetch_assoc()) 
	{
    }
	else 
	{
		echo "<script>window.alert('Invalid Email or Password!');</script>";
	    echo "<script>window.location.replace('/WadProject/login.html');</script>";
    
	}
	} 
	if($rs["Email"]==$Email && $rs["Password"]==$Password)
	{
		$_SESSION['logged_in_user']=array('name'=>$rs->name,'email'=>$Email);
		echo "<script>window.location.replace('TeacherHome.html');</script>";
	}
} 


?>