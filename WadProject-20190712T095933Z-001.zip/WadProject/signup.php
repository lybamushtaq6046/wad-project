<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>HR SignUp</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <link href="css/justified-nav.css" rel="stylesheet">
	
   <link href="css/signup.css" rel="stylesheet">

    <script src="js/ie-emulation-modes-warning.js"></script>

<style>
.red
{
	color:red;
}
</style>
  </head>

  <body>
	  <?php include("DataAccessHelper.php"); 
		?>
  
  
  <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php">HR management</a>
        </div>
      </div>
    </nav>
	
    <div class="container">
      <div class="masthead">
        
		<div id="navbar" class="navbar-collapse collapse">

        </div><!--/.navbar-collapse -->
		
        <nav>
          <ul class="nav nav-justified">
            <li><a href="index.php"> <- Home</a></li>
           
          </ul>
        </nav>
      </div>

      <div>
       
	 <form class="form-signup" method="POST" enctype="multipart/form-data" action="/code/View/my_project/Controller/signup_db.php" >
        <h2 class="form-signup-heading">Please sign up</h2>
		<label>Name</label>
        <input type="text" name="Name"  id="inputFirstName" class="form-control"  required autofocus>
		<label>Email address</label>
        <input type="email" name="Email" id="inputEmail" class="form-control"  required autofocus>
		<label>Password</label>
        <input type="password" name="Password" id="inputPassword" class="form-control"  required>
        <label>Phone Number</label>
        <input type="tel" name="Number" id="p_num" class="form-control"  required autofocus>
		<label>City</label>
        <input type="text" name="City" id="inputUsername" class="form-control"  required autofocus>
		<div class="checkbox">
          <label>
       <!--     <input type="checkbox" name="remember" value="remember-me"> Remember me   -->
          </label>
		</div>
		<div class="Radio button">
		  <input type="radio" name="type" value="SME"> SME
		  <input type="radio" name="type" value="personnel" checked> HR Personnel
		  <input type="radio" name="type" value="manager"> HR Manager
		</div>
           
				<p class=red> Note: your SignUp will be validated by an existing HR manager</p>
        <button class="btn btn-lg btn-primary btn-block" type="submit">Sign up</button>
      </form>
		
      </div>

      <!-- Site footer -->
      <footer class="footer">
        <p>&copy; 2017 Company, Inc.</p>
      </footer>

    </div><script src="js/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>
