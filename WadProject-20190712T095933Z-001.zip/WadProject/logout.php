<?php
session_start();
session_destroy();
header("Location: C:\xampp\htdocs\WadProject\login.html");
?>